( function () {
	const cfg = window.SBL || {};
	const freeAt = Number( cfg.freeAt ) || 6000;
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-KE' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.sbl-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'sbl-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'sbl-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => toast( '✓ Added to your cart' ) );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your cart' ) );

	/* Wishlist ---------------------------------------------------------- */
	const KEY = 'sbl-wishlist';
	const readWish = () => {
		try {
			return JSON.parse( localStorage.getItem( KEY ) || '[]' ).map( Number ).filter( Boolean );
		} catch ( e ) {
			return [];
		}
	};
	const writeWish = ( ids ) => {
		try {
			localStorage.setItem( KEY, JSON.stringify( ids ) );
		} catch ( e ) {}
	};
	function paintWish() {
		const ids = readWish();
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		$$( '[data-sbl-wish]' ).forEach( ( b ) => {
			const on = ids.includes( Number( b.dataset.sblWish ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		$$( '[data-sbl-wish-count]' ).forEach( ( el ) => {
			if ( el.textContent !== String( ids.length ) ) el.textContent = ids.length;
			el.hidden = ids.length === 0;
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-sbl-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.sblWish );
		let ids = readWish();
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		writeWish( ids );
		paintWish();
		toast( on ? 'Removed from your wishlist' : '♥ Saved to your <a href="' + ( cfg.shop || '/' ).replace( /shop\/?$/, '' ) + 'wishlist/">wishlist</a>' );
		if ( b.closest( '[data-sbl-wishlist]' ) ) renderWishlist();
	} );

	async function renderWishlist() {
		const box = document.querySelector( '[data-sbl-wishlist]' );
		if ( ! box ) return;
		const ids = readWish();
		if ( ! ids.length ) {
			box.innerHTML = '<div class="sbl-empty"><p>Your wishlist is empty. Tap the ♥ on any product to save it here.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse the shop</a></div>';
			return;
		}
		try {
			const res = await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=50' );
			const items = await res.json();
			box.innerHTML = '<div class="sbl-wish-grid">' + items.map( ( p ) => {
				const img = p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail || p.images[ 0 ].src ) + '" alt="" loading="lazy">' : '';
				return '<article class="sbl-wish-card"><a href="' + esc( p.permalink ) + '">' + img + '</a>' +
					'<button type="button" class="sbl-heart is-on" data-sbl-wish="' + p.id + '" aria-label="Remove from wishlist" aria-pressed="true"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg></button>' +
					'<h3><a href="' + esc( p.permalink ) + '">' + p.name + '</a></h3><div class="sbl-wish-price">' + p.price_html + '</div>' +
					'<a class="wp-element-button" href="' + esc( p.permalink ) + '">View options</a></article>';
			} ).join( '' ) + '</div>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load your wishlist. Please refresh the page.</p>';
		}
	}

	/* Product page options --------------------------------------------- */
	document.addEventListener( 'change', ( e ) => {
		const t = e.target;
		if ( t.name === 'sbl_colour' ) {
			$$( '[data-sbl-colour-label]' ).forEach( ( el ) => ( el.textContent = t.value ) );
			// Show the photo of that colour in the product gallery.
			const thumb = t.dataset.sblPhoto !== undefined && $$( '.woocommerce-product-gallery .flex-control-thumbs img' )[ Number( t.dataset.sblPhoto ) ];
			if ( thumb ) thumb.click();
		}
		if ( t.name === 'sbl_size' ) {
			$$( '[data-sbl-size-label]' ).forEach( ( el ) => ( el.textContent = t.value ) );
		}
		if ( t.matches( '[data-sbl-emb-toggle]' ) ) {
			const wrap = t.closest( '[data-sbl-emb]' );
			const fields = wrap.querySelector( '.sbl-emb__fields' );
			fields.hidden = ! t.checked;
			wrap.classList.toggle( 'is-on', t.checked );
			const input = wrap.querySelector( '[data-sbl-emb-text]' );
			input.required = t.checked;
			if ( t.checked ) input.focus();
		}
		if ( t.closest( '[data-sbl-emb]' ) ) paintEmb( t.closest( '[data-sbl-emb]' ) );
	} );
	document.addEventListener( 'input', ( e ) => {
		const wrap = e.target.closest( '[data-sbl-emb]' );
		if ( wrap ) paintEmb( wrap );
	} );
	const THREAD = { White: '#FFFFFF', Navy: '#1B2A4A', Black: '#15171A', Gold: '#C9A43A', Pink: '#E0558E', 'Royal Blue': '#1F4FB5' };
	function paintEmb( wrap ) {
		const text = wrap.querySelector( '[data-sbl-emb-text]' ).value.trim() || 'Your name here';
		const thread = wrap.querySelector( '[data-sbl-emb-thread]' ).value;
		const side = wrap.querySelector( '[data-sbl-emb-side]' ).value;
		const prev = wrap.querySelector( '[data-sbl-emb-preview]' );
		const dark = [ 'White', 'Gold', 'Pink' ].includes( thread );
		prev.style.setProperty( '--thread', THREAD[ thread ] || '#fff' );
		prev.classList.toggle( 'is-light', ! dark );
		prev.classList.toggle( 'is-right', side === 'Right chest' );
		prev.querySelector( 'span' ).textContent = text;
	}

	document.addEventListener( 'click', ( e ) => {
		const opener = e.target.closest( '[data-sbl-open]' );
		if ( ! opener ) return;
		const d = document.getElementById( opener.dataset.sblOpen );
		if ( d && d.showModal ) {
			e.preventDefault();
			d.showModal();
		}
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.sbl-dialog' ) ) e.target.close();
	} );

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.sbl-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'sbl-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const res = await fetch( cfg.store + 'products?search=' + encodeURIComponent( q ) + '&per_page=6' );
						const items = await res.json();
						if ( mine !== seq ) return;
						list.innerHTML = items.length
							? items.map( ( p ) => '<a href="' + esc( p.permalink ) + '">' + ( p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail ) + '" alt="">' : '' ) + '<span>' + p.name + '<small>' + p.price_html + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( q ) + '”</button>'
							: '<p>No products match “' + esc( q ) + '”.</p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	/* Free-delivery bar --------------------------------------------------- */
	function renderBar( total ) {
		const left = Math.max( 0, freeAt - total );
		const pct = Math.min( 100, Math.round( ( total / freeAt ) * 100 ) );
		const msg = left > 0
			? 'Add <strong>' + fmt( left ) + '</strong> more for <strong>free Nairobi express delivery</strong>'
			: "<strong>You've unlocked free Nairobi express delivery!</strong>";
		$$( '[data-sbl-freebar]' ).forEach( ( el ) => {
			el.innerHTML = msg + '<div class="sbl-freebar__track"><div class="sbl-freebar__fill" style="width:' + pct + '%"></div></div>';
		} );
	}
	function watchCart() {
		const data = window.wp && window.wp.data;
		if ( ! data || ! data.select( 'wc/store/cart' ) ) return;
		let last = null;
		data.subscribe( () => {
			const totals = data.select( 'wc/store/cart' ).getCartTotals();
			if ( ! totals || totals.total_items === undefined ) return;
			const sub = Number( totals.total_items ) / Math.pow( 10, totals.currency_minor_unit || 0 );
			if ( sub !== last ) {
				last = sub;
				renderBar( sub );
			}
		} );
	}

	function init() {
		paintWish();
		renderWishlist();
		initSearch();
		watchCart();
		// Cards re-render client-side in some blocks; keep hearts in sync.
		new MutationObserver( () => paintWish() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
