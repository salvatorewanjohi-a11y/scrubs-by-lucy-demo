<?php
/**
 * Scrubs by Lucy child theme.
 */

const SBL_FREE_DELIVERY = 6000; // KSh, keep in step with the Free Nairobi Express Delivery shipping method.
const SBL_EMBROIDERY    = 500;  // KSh added per embroidered item.
const SBL_WHATSAPP      = '254752190557';
const SBL_LOW_STOCK     = 3;
const SBL_EMBROIDER_CATS = [ 'scrubs', 'scrub-tops', 'scrub-jackets', 'lab-coats', 'nurse-uniforms' ];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'sbl-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap', [], null );
	wp_enqueue_style( 'sbl', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'sbl', $uri . '/assets/sbl.js', [], filemtime( $dir . '/assets/sbl.js' ), true );
	wp_localize_script( 'sbl', 'SBL', [
		'freeAt'    => SBL_FREE_DELIVERY,
		'store'     => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'      => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'sbl-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap', [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

/* -------------------------------------------------------------------------
 * Colours and sizes
 * ---------------------------------------------------------------------- */

/**
 * Swatch colour for a colour name. Anything unknown gets a neutral grey.
 */
function sbl_colour_css( $name ) {
	$map = [
		'royal blue'   => '#1F4FB5',
		'navy blue'    => '#1B2A4A',
		'ceil blue'    => '#8FB3D9',
		'sky blue'     => '#6EC1E4',
		'galaxy blue'  => '#2A3F8F',
		'blue'         => '#1F6FD1',
		'wine'         => '#6D1F3B',
		'maroon'       => '#6D1F3B',
		'purple'       => '#5B2A86',
		'surgical green' => '#0F7A5C',
		'hunter green' => '#1F5A3A',
		'green'        => '#2E9E5B',
		'teal'         => '#127C82',
		'mint'         => '#A8DCCB',
		'charcoal'     => '#3D4248',
		'gray'         => '#9AA3AD',
		'grey'         => '#9AA3AD',
		'black'        => '#15171A',
		'white'        => '#FFFFFF',
		'red'          => '#C62839',
		'magenta'      => '#C2185B',
		'coral pink'   => '#F28C82',
		'pink'         => '#F4A7C0',
		'orange'       => '#F07A1A',
		'gold'         => '#C9A43A',
		'silver'       => '#C0C4C9',
		'white & navy' => 'linear-gradient(135deg,#fff 50%,#1B2A4A 50%)',
		'printed'      => 'conic-gradient(#F4A7C0 0 25%,#8FB3D9 0 50%,#A8DCCB 0 75%,#F0C987 0)',
	];
	return $map[ strtolower( trim( html_entity_decode( $name ) ) ) ] ?? '#B8C2CC';
}

/**
 * Colour/size options a shopper chooses on the product page (attributes that are not variations).
 *
 * @return array{colour: WP_Term[], size: WP_Term[]}
 */
function sbl_choices( WC_Product $product ) {
	$out = [ 'colour' => [], 'size' => [] ];
	$attrs = $product->get_attributes();
	foreach ( [ 'colour', 'size' ] as $key ) {
		$tax = "pa_$key";
		if ( isset( $attrs[ $tax ] ) && ! $attrs[ $tax ]->get_variation() ) {
			$out[ $key ] = wc_get_product_terms( $product->get_id(), $tax, [ 'orderby' => 'menu_order' ] );
		}
	}
	return $out;
}

function sbl_can_embroider( WC_Product $product ) {
	return has_term( SBL_EMBROIDER_CATS, 'product_cat', $product->get_id() );
}

function sbl_needs_choices( WC_Product $product ) {
	$c = sbl_choices( $product );
	return $product->is_type( 'variable' ) || $c['colour'] || $c['size'];
}

/* -------------------------------------------------------------------------
 * Product page: swatches, sizes, embroidery
 * ---------------------------------------------------------------------- */

add_action( 'woocommerce_before_add_to_cart_quantity', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$c = sbl_choices( $product );

	if ( $c['colour'] ) {
		$single = count( $c['colour'] ) === 1;
		echo '<fieldset class="sbl-opt sbl-opt--colour"><legend>Colour: <strong data-sbl-colour-label>' . ( $single ? esc_html( $c['colour'][0]->name ) : 'choose one' ) . '</strong></legend><div class="sbl-swatches">';
		// Which gallery photo shows each colour (0 = main photo), set per product.
		$photos = (array) $product->get_meta( '_sbl_colour_images' );
		foreach ( $c['colour'] as $t ) {
			printf(
				'<label class="sbl-swatch" title="%1$s"><input type="radio" name="sbl_colour" value="%1$s" required%3$s%4$s><span style="background:%2$s"></span><em class="screen-reader-text">%1$s</em></label>',
				esc_attr( $t->name ),
				esc_attr( sbl_colour_css( $t->name ) ),
				$single ? ' checked' : '',
				isset( $photos[ $t->name ] ) ? ' data-sbl-photo="' . (int) $photos[ $t->name ] . '"' : ''
			);
		}
		echo '</div></fieldset>';
	}

	if ( $c['size'] ) {
		echo '<fieldset class="sbl-opt sbl-opt--size"><legend>Size: <strong data-sbl-size-label>choose one</strong>';
		if ( ! has_term( [ 'footwear' ], 'product_cat', $product->get_id() ) ) {
			echo ' <button type="button" class="sbl-link" data-sbl-open="sbl-size-guide">Size guide</button>';
		}
		echo '</legend><div class="sbl-sizes">';
		foreach ( $c['size'] as $t ) {
			printf( '<label class="sbl-size"><input type="radio" name="sbl_size" value="%1$s" required><span>%1$s</span></label>', esc_attr( $t->name ) );
		}
		echo '</div></fieldset>';
	}

	if ( sbl_can_embroider( $product ) ) {
		?>
		<div class="sbl-emb" data-sbl-emb>
			<label class="sbl-emb__toggle"><input type="checkbox" name="sbl_emb" value="1" data-sbl-emb-toggle>
				<span><strong>Add name embroidery</strong> <em>+ KSh <?php echo number_format( SBL_EMBROIDERY ); ?></em><small>Your name and title stitched on the chest</small></span>
			</label>
			<div class="sbl-emb__fields" hidden>
				<label>Name &amp; qualifications<input type="text" name="sbl_emb_text" maxlength="30" placeholder="e.g. Dr. A. Omondi, MBChB" data-sbl-emb-text></label>
				<div class="sbl-emb__row">
					<label>Thread colour<select name="sbl_emb_thread" data-sbl-emb-thread>
						<?php foreach ( [ 'White', 'Navy', 'Black', 'Gold', 'Pink', 'Royal Blue' ] as $t ) echo '<option>' . esc_html( $t ) . '</option>'; ?>
					</select></label>
					<label>Position<select name="sbl_emb_side" data-sbl-emb-side><option>Left chest</option><option>Right chest</option></select></label>
				</div>
				<div class="sbl-emb__preview" data-sbl-emb-preview><span>Your name here</span></div>
			</div>
		</div>
		<?php
	}
} );

// Size guide pop-up on product pages, and as a page of its own.
function sbl_size_guide_html() {
	$rows = [
		[ 'XS', '82–87', '66–71', '68' ],
		[ 'S', '88–93', '72–77', '70' ],
		[ 'M', '94–100', '78–84', '72' ],
		[ 'L', '101–108', '85–92', '74' ],
		[ 'XL', '109–116', '93–100', '76' ],
		[ '2XL', '117–124', '101–108', '78' ],
		[ '3XL', '125–132', '109–116', '80' ],
	];
	$h = '<div class="sbl-size-table"><table><thead><tr><th>Size</th><th>Chest (cm)</th><th>Waist (cm)</th><th>Top length (cm)</th></tr></thead><tbody>';
	foreach ( $rows as $r ) {
		$h .= '<tr><td><strong>' . $r[0] . '</strong></td><td>' . $r[1] . '</td><td>' . $r[2] . '</td><td>' . $r[3] . '</td></tr>';
	}
	$h .= '</tbody></table></div>';
	$h .= '<p class="sbl-small">Scrubs and jackets are unisex. Measure around the fullest part of your chest and your natural waist. Between sizes? Go one up for a relaxed fit, or pop into the shop and try both. Footwear follows EU sizes 37–44.</p>';
	return $h;
}
add_shortcode( 'sbl_size_guide', 'sbl_size_guide_html' );

add_action( 'wp_footer', function () {
	if ( ! is_product() ) {
		return;
	}
	echo '<dialog id="sbl-size-guide" class="sbl-dialog"><form method="dialog"><button class="sbl-dialog__close" aria-label="Close">×</button></form><h2>Size guide</h2>' . sbl_size_guide_html() . '</dialog>';
} );

add_filter( 'woocommerce_add_to_cart_validation', function ( $ok, $product_id ) {
	$product = wc_get_product( $product_id );
	if ( ! $product ) {
		return $ok;
	}
	$c = sbl_choices( $product );
	if ( count( $c['colour'] ) > 1 && empty( $_REQUEST['sbl_colour'] ) ) {
		wc_add_notice( 'Please choose a colour.', 'error' );
		return false;
	}
	if ( $c['size'] && empty( $_REQUEST['sbl_size'] ) ) {
		wc_add_notice( 'Please choose a size.', 'error' );
		return false;
	}
	if ( ! empty( $_REQUEST['sbl_emb'] ) && trim( wp_unslash( $_REQUEST['sbl_emb_text'] ?? '' ) ) === '' ) {
		wc_add_notice( 'Please enter the name to embroider, or untick embroidery.', 'error' );
		return false;
	}
	return $ok;
}, 10, 2 );

add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	$product = wc_get_product( $product_id );
	if ( ! $product ) {
		return $data;
	}
	$c = sbl_choices( $product );
	$clean = fn( $k ) => sanitize_text_field( wp_unslash( $_REQUEST[ $k ] ?? '' ) );
	if ( $c['colour'] ) {
		$data['sbl_colour'] = $clean( 'sbl_colour' ) ?: $c['colour'][0]->name;
	}
	if ( $c['size'] && $clean( 'sbl_size' ) ) {
		$data['sbl_size'] = $clean( 'sbl_size' );
	}
	if ( ! empty( $_REQUEST['sbl_emb'] ) && sbl_can_embroider( $product ) ) {
		$data['sbl_emb'] = [
			'text'   => mb_substr( $clean( 'sbl_emb_text' ), 0, 30 ),
			'thread' => $clean( 'sbl_emb_thread' ) ?: 'White',
			'side'   => $clean( 'sbl_emb_side' ) ?: 'Left chest',
		];
	}
	return $data;
}, 10, 2 );

function sbl_item_lines( array $item ) {
	$lines = [];
	if ( ! empty( $item['sbl_colour'] ) ) $lines['Colour'] = $item['sbl_colour'];
	if ( ! empty( $item['sbl_size'] ) ) $lines['Size'] = $item['sbl_size'];
	if ( ! empty( $item['sbl_emb'] ) ) {
		$e = $item['sbl_emb'];
		$lines['Embroidery'] = '"' . $e['text'] . '" – ' . $e['thread'] . ' thread, ' . strtolower( $e['side'] ) . ' (+KSh ' . number_format( SBL_EMBROIDERY ) . ')';
	}
	return $lines;
}

add_filter( 'woocommerce_get_item_data', function ( $out, $item ) {
	foreach ( sbl_item_lines( $item ) as $k => $v ) {
		$out[] = [ 'key' => $k, 'value' => $v ];
	}
	return $out;
}, 10, 2 );

add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	foreach ( $cart->get_cart() as $item ) {
		if ( empty( $item['sbl_emb'] ) ) {
			continue;
		}
		$fresh = wc_get_product( $item['variation_id'] ?: $item['product_id'] );
		if ( $fresh ) {
			$item['data']->set_price( (float) $fresh->get_price() + SBL_EMBROIDERY );
		}
	}
}, 20 );

add_action( 'woocommerce_checkout_create_order_line_item', function ( $line, $key, $item ) {
	foreach ( sbl_item_lines( $item ) as $k => $v ) {
		$line->add_meta_data( $k, $v );
	}
}, 10, 3 );

// "Complete the set": the product's upsells, under the add-to-cart button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$ids = array_slice( $product->get_upsell_ids(), 0, 3 );
	if ( ! $ids ) {
		return;
	}
	echo '<div class="sbl-set"><p class="sbl-set__title">Complete the set</p>';
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p || ! $p->is_visible() ) continue;
		printf(
			'<a class="sbl-set__item" href="%s">%s<span><strong>%s</strong>%s</span><em>View</em></a>',
			esc_url( $p->get_permalink() ),
			$p->get_image( 'thumbnail' ),
			esc_html( $p->get_name() ),
			$p->get_price_html()
		);
	}
	echo '</div>';
} );

// Fabric & care and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$fabric = get_post_meta( $product->get_id(), '_sbl_fabric', true );
	if ( $fabric ) {
		$tabs['sbl_fabric'] = [
			'title'    => 'Fabric & care',
			'priority' => 15,
			'callback' => function () use ( $fabric ) {
				echo wpautop( wp_kses_post( $fabric ) );
			},
		];
	}
	$tabs['sbl_delivery'] = [
		'title'    => 'Delivery & pickup',
		'priority' => 25,
		'callback' => function () {
			echo '<ul><li><strong>Nairobi express:</strong> same-day dispatch for orders placed before 3 PM, KSh 300. Free on orders over KSh ' . number_format( SBL_FREE_DELIVERY ) . '.</li><li><strong>Upcountry courier:</strong> 1–3 days to any county, KSh 500.</li><li><strong>In-store pickup:</strong> free from The Bazaar, 1st Floor B05, Moi Avenue. We\'ll call when it\'s ready.</li><li>Embroidered items are usually ready in 1–2 working days.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function sbl_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Hover image (first gallery photo) and wishlist heart on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = sbl_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'sbl-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$heart = sprintf(
		'<button type="button" class="sbl-heart" data-sbl-wish="%d" aria-label="Save %s to wishlist" aria-pressed="false"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg></button>',
		$product->get_id(),
		esc_attr( $product->get_name() )
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $heart . '</div>', $pos, 6 );
}, 10, 3 );

// Spec badge above the price, colour dots below it.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = sbl_card_product( $instance );
	if ( ! $product ) {
		return $content;
	}
	$before = '';
	$spec = get_post_meta( $product->get_id(), '_sbl_spec', true );
	if ( $spec ) {
		$before .= '<span class="sbl-badge">' . esc_html( $spec ) . '</span>';
	}
	if ( ! $product->is_in_stock() ) {
		$before .= '<span class="sbl-badge sbl-badge--out">Out of stock</span>';
	} elseif ( $product->managing_stock() && (int) $product->get_stock_quantity() <= SBL_LOW_STOCK ) {
		$before .= '<span class="sbl-badge sbl-badge--low">Only ' . (int) $product->get_stock_quantity() . ' left</span>';
	}
	$after = '';
	if ( ! empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		$colours = sbl_choices( $product )['colour'];
		if ( count( $colours ) > 1 ) {
			$after = '<div class="sbl-dots" aria-label="' . count( $colours ) . ' colours">';
			foreach ( array_slice( $colours, 0, 7 ) as $t ) {
				$after .= '<span title="' . esc_attr( $t->name ) . '" style="background:' . esc_attr( sbl_colour_css( $t->name ) ) . '"></span>';
			}
			if ( count( $colours ) > 7 ) {
				$after .= '<em>+' . ( count( $colours ) - 7 ) . '</em>';
			}
			$after .= '</div>';
		}
	}
	return ( $before ? '<div class="sbl-badges">' . $before . '</div>' : '' ) . $content . $after;
}, 10, 3 );

// Sale badge shows the saving, e.g. "−18%".
add_filter( 'render_block_woocommerce/product-sale-badge', function ( $content, $block, $instance ) {
	$product = sbl_card_product( $instance );
	if ( ! $product || ! $product->is_on_sale() ) {
		return $content;
	}
	$pct = 0;
	foreach ( $product->is_type( 'variable' ) ? $product->get_available_variations( 'objects' ) : [ $product ] as $p ) {
		$reg  = (float) $p->get_regular_price();
		$sale = (float) $p->get_sale_price();
		if ( $reg > 0 && $sale > 0 ) {
			$pct = max( $pct, round( ( $reg - $sale ) / $reg * 100 ) );
		}
	}
	return $pct ? preg_replace( '#>\s*Sale\s*<#', '>−' . $pct . '%<', $content, 1 ) : $content;
}, 10, 3 );

// Products that need a colour or size go to the product page instead of adding straight to the cart.
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product ) {
	if ( $product->is_purchasable() && $product->is_in_stock() && sbl_needs_choices( $product ) ) {
		return sbl_choices( $product )['size'] ? 'Choose size' : 'Choose options';
	}
	return $text;
}, 10, 2 );
add_filter( 'woocommerce_product_add_to_cart_url', function ( $url, $product ) {
	return ! is_product() && sbl_needs_choices( $product ) ? $product->get_permalink() : $url;
}, 10, 2 );
add_filter( 'woocommerce_product_supports', function ( $supports, $feature, $product ) {
	return $feature === 'ajax_add_to_cart' && sbl_needs_choices( $product ) ? false : $supports;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page sections
 * ---------------------------------------------------------------------- */

add_shortcode( 'sbl_roles', function () {
	$roles = [
		'doctors-surgeons'     => [ 'Doctors & Surgeons', 'role-doctors' ],
		'nurses-midwives'      => [ 'Nurses & Midwives', 'role-nurses' ],
		'clinical-students'    => [ 'Clinical Students', 'role-students' ],
		'dental-allied-health' => [ 'Dental & Allied Health', 'role-dental' ],
		'lab-diagnostics'      => [ 'Lab & Diagnostics', 'role-lab' ],
	];
	$h = '<div class="sbl-roles">';
	foreach ( $roles as $slug => [ $name, $img ] ) {
		$term = get_term_by( 'slug', $slug, 'product_tag' );
		if ( ! $term ) continue;
		$h .= sprintf(
			'<a class="sbl-role" href="%s"><img src="%s" alt="" loading="lazy" width="300" height="400"><span><strong>%s</strong><em>%d products</em></span></a>',
			esc_url( get_term_link( $term ) ),
			esc_url( get_stylesheet_directory_uri() . "/assets/photos/$img.webp" ),
			esc_html( $name ),
			(int) $term->count
		);
	}
	return $h . '</div>';
} );

add_shortcode( 'sbl_colours', function () {
	$terms = get_terms( [ 'taxonomy' => 'pa_colour', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 12 ] );
	if ( is_wp_error( $terms ) || ! $terms ) {
		return '';
	}
	$h = '<div class="sbl-colours"><p class="sbl-colours__label">Shop by colour</p><div class="sbl-colours__list">';
	foreach ( $terms as $t ) {
		$h .= sprintf(
			'<a href="%s"><span style="background:%s"></span>%s</a>',
			esc_url( get_term_link( $t ) ),
			esc_attr( sbl_colour_css( $t->name ) ),
			esc_html( $t->name )
		);
	}
	return $h . '</div></div>';
} );

// Category and colour chips above shop, category, colour and search results.
add_shortcode( 'sbl_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="sbl-filters" aria-label="Filter products"><div class="sbl-filters__row">';
	$h .= '<a class="sbl-chip' . ( is_shop() ? ' is-on' : '' ) . '" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">All</a>';
	foreach ( get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'term_id' ] ) as $t ) {
		$h .= sprintf( '<a class="sbl-chip%s" href="%s">%s <em>%d</em></a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ), (int) $t->count );
	}
	$h .= '</div><div class="sbl-filters__row sbl-filters__row--colours"><span>Colour</span>';
	foreach ( get_terms( [ 'taxonomy' => 'pa_colour', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 14 ] ) as $t ) {
		$h .= sprintf(
			'<a class="sbl-colour-dot%s" href="%s" title="%s" aria-label="%3$s"><span style="background:%s"></span></a>',
			$t->term_id === $cur_id ? ' is-on' : '',
			esc_url( get_term_link( $t ) ),
			esc_attr( $t->name ),
			esc_attr( sbl_colour_css( $t->name ) )
		);
	}
	return $h . '</div></nav>';
} );

add_shortcode( 'sbl_wishlist', function () {
	return '<div class="sbl-wishlist" data-sbl-wishlist><p class="sbl-small">Loading your saved items…</p></div>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function sbl_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, SBL_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / SBL_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>KSh ' . number_format( $left ) . '</strong> more for <strong>free Nairobi express delivery</strong>'
		: '<strong>You\'ve unlocked free Nairobi express delivery!</strong>';
	return '<div class="sbl-freebar" data-sbl-freebar>' . $msg . '<div class="sbl-freebar__track"><div class="sbl-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => sbl_freebar_html() . $c );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-filled-mini-cart-contents-block[^>]*>)#', '$1' . sbl_freebar_html(), $c, 1 );
} );

// Designation at checkout, so the shop knows who it's dressing.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'sbl/designation',
		'label'    => 'Role',
		'location' => 'contact',
		'type'     => 'select',
		'required' => false,
		'options'  => array_map( fn( $v ) => [ 'value' => $v, 'label' => $v ], [ 'Doctor', 'Nurse / Midwife', 'Clinical Officer', 'Medical Student', 'Dentist', 'Lab Technologist', 'Pharmacist', 'Other' ] ),
	] );
} );

// WhatsApp order summary on the order confirmation page.
function sbl_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Scrubs by Lucy, I just placed order #' . $order->get_order_number() . ':' ];
	foreach ( $order->get_items() as $item ) {
		$meta = [];
		foreach ( [ 'Colour', 'Size', 'Embroidery' ] as $k ) {
			$v = $item->get_meta( $k );
			if ( $v ) $meta[] = "$k: $v";
		}
		$lines[] = '• ' . $item->get_quantity() . ' × ' . $item->get_name() . ( $meta ? ' (' . implode( '; ', $meta ) . ')' : '' );
	}
	$lines[] = 'Total: KSh ' . number_format( (float) $order->get_total() );
	$lines[] = 'Delivery: ' . $order->get_shipping_method();
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return 'https://wa.me/' . SBL_WHATSAPP . '?text=' . rawurlencode( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="sbl-thanks"><p>Your order number is <strong>#' . esc_html( $order->get_order_number() ) . '</strong>. Send us the summary on WhatsApp and we\'ll confirm it straight away.</p><a class="wp-element-button sbl-wa-btn" href="' . esc_attr( sbl_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">Send order on WhatsApp</a></div>';
} );

// Newsletter: store the email and hand over the KSh 500 welcome code.
add_action( 'admin_post_nopriv_sbl_subscribe', 'sbl_subscribe' );
add_action( 'admin_post_sbl_subscribe', 'sbl_subscribe' );
function sbl_subscribe() {
	check_admin_referer( 'sbl_subscribe' );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$back  = wp_get_referer() ?: home_url( '/' );
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'sbl_sub', 'invalid', $back ) . '#newsletter' );
		exit;
	}
	$list = get_option( 'sbl_subscribers', [] );
	$list[ strtolower( $email ) ] = current_time( 'mysql' );
	update_option( 'sbl_subscribers', $list, false );
	wp_safe_redirect( add_query_arg( 'sbl_sub', 'ok', $back ) . '#newsletter' );
	exit;
}

add_shortcode( 'sbl_newsletter', function () {
	$state = sanitize_key( $_GET['sbl_sub'] ?? '' );
	if ( $state === 'ok' ) {
		return '<p class="sbl-news-ok"><strong>Welcome to the Med-Club!</strong> Use code <strong class="sbl-pink">MEDCLUB500</strong> at checkout for KSh 500 off your first order.</p>';
	}
	$err = $state === 'invalid' ? '<p class="sbl-news-err">Please enter a valid email address.</p>' : '';
	return '<form class="sbl-news-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="sbl_subscribe">'
		. wp_nonce_field( 'sbl_subscribe', '_wpnonce', true, false )
		. '<input type="email" name="email" required placeholder="Your email address" aria-label="Email address">'
		. '<button class="wp-element-button" type="submit">Get KSh 500 off</button>'
		. '</form>' . $err;
} );

// Staff see the subscriber list under WooCommerce.
add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Med-Club subscribers', 'Subscribers', 'manage_woocommerce', 'sbl-subscribers', function () {
		$list = get_option( 'sbl_subscribers', [] );
		echo '<div class="wrap"><h1>Med-Club subscribers (' . count( $list ) . ')</h1><table class="widefat striped"><thead><tr><th>Email</th><th>Signed up</th></tr></thead><tbody>';
		foreach ( array_reverse( $list, true ) as $email => $when ) {
			echo '<tr><td>' . esc_html( $email ) . '</td><td>' . esc_html( $when ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

// Staff edit the card badge and the fabric & care text on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_sbl_spec', 'label' => 'Card badge', 'description' => 'Short label on the product card, e.g. "4-Way Stretch".', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_sbl_fabric', 'label' => 'Fabric & care', 'rows' => 5 ] );
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_sbl_spec' => 'sanitize_text_field', '_sbl_fabric' => 'wp_kses_post' ] as $key => $clean ) {
		if ( isset( $_POST[ $key ] ) ) {
			$product->update_meta_data( $key, $clean( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and riders need a phone number.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate (e.g. Westlands, Kilimani)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon: the shop's logo.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
